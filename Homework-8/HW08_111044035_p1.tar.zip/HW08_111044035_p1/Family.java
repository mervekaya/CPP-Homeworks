package HW08_111044035_p1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Merve KAYA
 */


public class Family  {
    
    private int numOfChild; 
    private Person[] children;
    private Person father;
    private Person mother;
    private static int count = 0;
    
    public Family()
    {
    	super();
    	numOfChild = 0;
        this.children = new Person[5];
    	++count;
    }
    
    public Family(Person mother,Person father)
    {
        if(mother.getSex() != 'F' && mother.getSex() != 'f')
            throw new IllegalArgumentException("Error: Mother must be female !.\n");
        else if(father.getSex() != 'M' && father.getSex() != 'm')
            throw new IllegalArgumentException("Error: Father must be male !.\n");
        else
        {
            setFather(father);
            setMother(mother); 
            this.children = new Person[5];
            numOfChild = 0;
            ++count;
        }
        
    }
    public Person getFather() {
        return father;
    }

    public Person getMother() {
        return mother;
    }
   public final void setFather(Person newFather)
    {
      father = new Person(newFather.getFirstName(),
                          newFather.getLastName(),
                          newFather.getBirthYear(),'M');

    }
    public final void setMother(Person newMother)
    {
       mother = new Person(newMother.getFirstName(),
                           newMother.getLastName(),
                           newMother.getBirthYear(),'F');
    }
    public void setChildren(Person[] childreen) {
        this.children = childreen;
    }

    public Person[] getChildren() {
        return children;
    }
   
    public void setNumOfChild(int numOfChild) {
        this.numOfChild = numOfChild;
    }

    public int getNumOfChild() {
        return numOfChild;
    }
    public Person at(int index)
    {
        try{
            return children[index];
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.printf("There is not child index %d . "
                    + "Exception thrown  : ", index);
            return null;
        }
    }
    public static int getCount()
    {
        return count;
    }
    public Boolean equals(Family newFamily)
    {
        Boolean isEqualFat = getFather().equals(newFamily.getFather());
        Boolean isEqualMot =  getMother().equals(newFamily.getMother());
        Boolean isEqualNum = getNumOfChild() == newFamily.getNumOfChild();
        Boolean isEqualChild;
        
        for(int i = 0 ; i < getNumOfChild(); ++i)
        {
            isEqualChild= children[i].equals(newFamily.children[i]);
            if(isEqualChild == Boolean.FALSE)
                return Boolean.FALSE;
        }
        return (isEqualFat && isEqualMot & isEqualNum);
                      
    }
    public Family add(Person newChild)
    {
        if(getNumOfChild() > 0)
        {
            Person[] oldChildren = new Person[getNumOfChild()];
            for(int i = 0 ; i < getNumOfChild() ; ++i)
                oldChildren[i] = children[i];
            children = new Person[getNumOfChild() * 2];
            for(int i = 0 ; i < getNumOfChild() ; ++i)
                children[i] = oldChildren[i];
            children[numOfChild] = newChild;
            ++numOfChild;
            return this;
        }
        else
        {
            children[0] = newChild;
            ++numOfChild;
            return this;
        }
          
    } 
    public static Boolean isRelative(Person person1,Person person2,Family[] family)
    {
        Boolean temp1 = Boolean.FALSE;
        Boolean temp2 = Boolean.FALSE;
        
        if(person1.equals(person2) == Boolean.TRUE)
              return Boolean.TRUE;
        for(int i = 0 ; i < family.length ;++i)
        {
       
            temp1 = person1.equals(family[i].getMother()) ||
                    person1.equals(family[i].getFather());
             
            temp2 = person2.equals(family[i].getMother()) ||
                    person2.equals(family[i].getFather());
            if(temp1 && temp2)
                return Boolean.TRUE;      
            else
            {
                temp1 = Boolean.FALSE;
                temp2 = Boolean.FALSE;
                
                for(int j = 0 ; j < family[i].getNumOfChild() ; ++j)
                {
       
                    if(person1.equals(family[i].children[j]) == Boolean.TRUE)
                        temp1 = Boolean.TRUE;
                } 
                if(temp1 == Boolean.TRUE)
                {
                    for(int j = 0 ; j < family[i].getNumOfChild() ; ++j)
                    {
                          if(person2.equals(family[i].children[j]) == Boolean.TRUE)
                                   return Boolean.TRUE;
                    }   
                    
                 }
              }
             
        }
        return Boolean.FALSE;
    }
    
    @Override
    public String toString()
    {
        String result;
        result = "MOTHER\n" + mother.toString() + "\nFATHER\n" + father.toString();
        for(int i = 0 ; i < getNumOfChild() ; ++i)
               result += "\nCHILDREN\n" + children[i].toString();
        return result;
    }
    
}    

