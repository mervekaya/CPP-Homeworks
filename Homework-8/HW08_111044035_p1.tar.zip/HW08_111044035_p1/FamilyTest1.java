package HW08_111044035_p1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Merve KAYA
 * ID Number : 111044035
 * 
 * This program make families.User can add child , access family , compare two family,
 * learn number of family , access the child at the given index and can learn one person
 * if is relative another person.
 */

public class FamilyTest1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
		Person smithChild1 = new Person("John","SMITH",1993,'M');
                Person smithChild2 = new Person("Marry","SMITH",1998,'f');
                Person smithMother = new Person("Britney","SMITH",1970,'f');
                Person smithFather = new Person("Paul","SMITH",1965,'m');
                
                Family smithFamily = new Family(smithMother,smithFather); 
                smithFamily.add(smithChild1);
                smithFamily.add(smithChild2);
	
               
                Person iglesiasFather = new Person("Enrique","IGLESIAS",1965,'m');
                Person iglesiasMother = new Person("Marry","IGLESIAS",1965,'f');
                Person iglesiasChild1 = new Person("Britney","IGLESIAS",1980,'F');
                
                Family iglesiasFamily = new Family(iglesiasMother,iglesiasFather);
                iglesiasFamily.add(iglesiasChild1);
                
                Person otherChild1 = new Person("John","SMITH",1993,'M');
                Person otherChild2 = new Person("Marry","SMITH",1998,'f');
                Person otherMother = new Person("Britney","SMITH",1970,'f');
                Person otherFather = new Person("Paul","SMITH",1965,'m');
                
                Family otherFamily = new Family(otherMother,otherFather); 
                otherFamily.add(otherChild1);
                otherFamily.add(otherChild2);
                
                Person johnsonFather = new Person("Austin","JOHNSON",1954,'M');
                Person johnsonMother = new Person("Shani","JOHNSON",1960,'F');
                Person johnsonChild1 = new Person("Dani","JOHNSON",1980,'F');
                Person johnsonChild2 = new Person("Evan","JOHNSON",1985,'M');
                Person johnsonChild3 = new Person("Nelida","JOHNSON",1990,'F');
                Person johnsonChild4 = new Person("Britney","IGLESIAS",1980,'F');
                
                Family johnsonFamily = new Family(johnsonMother,johnsonFather);
                johnsonFamily.add(johnsonChild1);
                johnsonFamily.add(johnsonChild2);
                johnsonFamily.add(johnsonChild3);
                johnsonFamily.add(johnsonChild4);
                
               
                
                Family[] arrayFamily = new Family[4];
                arrayFamily[0] = smithFamily;
                arrayFamily[1] = iglesiasFamily;
                arrayFamily[2] = otherFamily;
                arrayFamily[3] = johnsonFamily;
                
                for(int i = 0 ; i < arrayFamily.length ; ++i)
                {
                    System.out.println(arrayFamily[i]);
                    System.out.println("\n---------------------\n");
                }
                if(Family.isRelative(otherChild1,johnsonChild1,arrayFamily) == Boolean.TRUE)
                    System.out.printf("%s and %s are relative .\n\n",otherChild1.getFirstName(),
                                      johnsonChild1.getFirstName());
                else
                    System.out.printf("%s and %s are not relative\n\n",otherChild1.getFirstName(),
                            johnsonChild1.getFirstName());
                
                if(Family.isRelative(iglesiasChild1,johnsonChild1,arrayFamily) == Boolean.TRUE)
                    System.out.printf("%s and %s are relative .\n\n",iglesiasChild1.getFirstName(),
                                      johnsonChild1.getFirstName());
                else
                    System.out.printf("%s and %s are not relative\n\n",iglesiasChild1.getFirstName(),
                            johnsonChild1.getFirstName());
                    
                 if(otherFamily.equals(smithFamily) == Boolean.TRUE)
                    System.out.printf("SMITH Family and OTHER Family are equal.\n\n");
                else
                    System.out.printf("SMITH Family and OTHER Family aren't equal.\n\n");
                
                if(otherFamily.equals(iglesiasFamily) == Boolean.TRUE)
                    System.out.printf("OTHER Family and IGLESIAS Family are equal.\n\n");
                else
                    System.out.printf("OTHER Family and IGLESIAS Family aren't equal.\n\n");
                
               System.out.printf("Second number child of Smith family is \n%s"
                                                                 ,smithFamily.at(1));
               System.out.printf("\n\nNumber of families : %d\n\n",Family.getCount());
                
                
}
    

        // TODO code application logic her
}
    
