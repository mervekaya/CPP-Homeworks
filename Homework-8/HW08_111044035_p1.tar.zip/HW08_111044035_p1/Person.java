package HW08_111044035_p1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Merve KAYA
 */

public class Person {

    /**
     * @param args the command line arguments
     */
   private String firstName;
   private String lastName;
   private int birthYear;
   private char sex;
   
   public Person()
   {
   	firstName = "First Name";
   	lastName = "Last Name";
   	birthYear = 0000;
   	sex = 'F';
   }
   public Person(String first,String last,int year,char sex)
   {
       firstName = first;
       lastName = last;
       birthYear = year;
       setSex(sex);
   }

    public void setBirthYear(int birthYear) {
        this.birthYear = birthYear;
    }

    public int getBirthYear() {
        return birthYear;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public final void setSex(char sex) {
      this.sex = (sex == 'M' || sex == 'm' ) ? 'M' : 'F';
        
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public char getSex() {
        return sex;
    }
    public Boolean equals(Person newPerson)
    {
        return ((getFirstName() == newPerson.getFirstName()) && 
                (getLastName() == newPerson.getLastName()) &&
                (getBirthYear() == newPerson.getBirthYear()) &&
                (getSex() == newPerson.getSex()));
    }       
   @Override
   public String toString()
   {
       return String.format("%s : %s\n%s : %s\n%s : %d\n%s : %c\n","Name",this.getFirstName(),
               "Sirname",this.getLastName(),"Birth Year",this.getBirthYear(),"Sex",
               this.getSex());
   }
    
}
